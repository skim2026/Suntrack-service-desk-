import os, tempfile, unittest
import app

class SunTrackTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.NamedTemporaryFile(delete=False)
        self.tmp.close()
        app.DB_PATH = self.tmp.name
        app.init_db()
    def tearDown(self):
        os.unlink(self.tmp.name)
    def sample(self, **extra):
        data = dict(customer="Taylor Morgan", address="10 Sample Rd, Las Vegas",
                    phone="702-555-0111", system_kw="7.2", service_type="Inverter",
                    description="Inverter communication fault", priority="High",
                    status="Open", scheduled_date="2026-12-02", billable="1")
        data.update(extra)
        return data
    def test_create_ticket_persists(self):
        ticket_id = app.create_ticket(self.sample())
        self.assertEqual(ticket_id, 1)
        self.assertEqual(len(app.all_tickets()), 1)
        self.assertEqual(app.all_tickets()[0]["customer"], "Taylor Morgan")
    def test_required_fields_rejected(self):
        with self.assertRaises(ValueError):
            app.create_ticket(self.sample(customer=""))
    def test_invalid_service_type_rejected(self):
        with self.assertRaises(ValueError):
            app.create_ticket(self.sample(service_type="Invalid"))
    def test_search_matches_description(self):
        app.create_ticket(self.sample())
        self.assertEqual(len(app.all_tickets(search="communication")), 1)
        self.assertEqual(len(app.all_tickets(search="not found")), 0)
    def test_status_update(self):
        ticket_id = app.create_ticket(self.sample())
        app.update_status(ticket_id, "Completed")
        self.assertEqual(app.all_tickets()[0]["status"], "Completed")
    def test_billable_flag_saved(self):
        app.create_ticket(self.sample())
        self.assertEqual(app.all_tickets()[0]["billable"], 1)

if __name__ == "__main__":
    unittest.main()
