"""SunTrack Service Desk: standard-library Python web app and SQLite database."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, quote
from html import escape
from pathlib import Path
import sqlite3, os, threading, unittest, tempfile

ROOT = Path(__file__).resolve().parent
DB_PATH = os.environ.get("SUNTRACK_DB", str(ROOT / "solar_service.db"))
STATUSES = ["Open", "Scheduled", "In Progress", "Waiting on Parts", "Completed"]
PRIORITIES = ["Low", "Normal", "High", "Urgent"]
TYPES = ["Monitoring", "Inverter", "Battery", "Roof / Mounting", "Electrical", "Inspection", "Other"]

def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.execute("""CREATE TABLE IF NOT EXISTS tickets(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer TEXT NOT NULL, address TEXT NOT NULL, phone TEXT DEFAULT '',
            system_kw REAL, service_type TEXT NOT NULL, description TEXT NOT NULL,
            priority TEXT NOT NULL, status TEXT NOT NULL, scheduled_date TEXT DEFAULT '',
            billable INTEGER NOT NULL DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP)""")

def create_ticket(data):
    required = ["customer", "address", "description"]
    if any(not data.get(k, "").strip() for k in required):
        raise ValueError("Customer, address, and issue description are required.")
    if data.get("service_type") not in TYPES:
        raise ValueError("Choose a valid service type.")
    if data.get("priority") not in PRIORITIES or data.get("status") not in STATUSES:
        raise ValueError("Choose a valid priority and status.")
    size = data.get("system_kw", "").strip()
    try:
        system_kw = float(size) if size else None
        if system_kw is not None and system_kw < 0:
            raise ValueError
    except ValueError:
        raise ValueError("System size must be a valid non-negative number.")
    with connect() as db:
        cur = db.execute("""INSERT INTO tickets
            (customer,address,phone,system_kw,service_type,description,priority,status,scheduled_date,billable)
            VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (data["customer"].strip(), data["address"].strip(), data.get("phone","").strip(),
             system_kw, data["service_type"], data["description"].strip(), data["priority"],
             data["status"], data.get("scheduled_date","").strip(), int(data.get("billable") == "1")))
        return cur.lastrowid

def update_status(ticket_id, status):
    if status not in STATUSES:
        raise ValueError("Invalid status.")
    with connect() as db:
        db.execute("UPDATE tickets SET status=? WHERE id=?", (status, ticket_id))

def all_tickets(search="", status=""):
    sql = "SELECT * FROM tickets WHERE 1=1"
    args = []
    if search:
        sql += " AND (customer LIKE ? OR address LIKE ? OR description LIKE ?)"
        term = "%" + search + "%"
        args.extend([term, term, term])
    if status in STATUSES:
        sql += " AND status=?"
        args.append(status)
    sql += " ORDER BY id DESC"
    with connect() as db:
        return db.execute(sql, args).fetchall()

def layout(title, body):
    return f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
    <title>{escape(title)} | SunTrack</title><style>
    *{{box-sizing:border-box}}body{{margin:0;background:#f3f6fa;color:#213449;font:15px Arial,sans-serif}}
    header{{background:#15344f;color:white;padding:20px max(22px,calc((100% - 1050px)/2));display:flex;justify-content:space-between;align-items:center}}
    header b{{font-size:20px}}header a{{color:#d8f6fa;margin-left:18px;text-decoration:none}}
    main{{max-width:1050px;margin:30px auto;padding:0 20px}}h1{{color:#173a59}}.hero{{background:linear-gradient(120deg,#173a59,#2676a7);color:white;border-radius:15px;padding:28px;margin-bottom:20px}}
    .hero h1{{color:white;margin:0 0 8px}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}}
    .card,.panel{{background:white;border:1px solid #e0e7ed;border-radius:12px;padding:18px;box-shadow:0 3px 12px #183c5910}}
    .card span{{color:#73869a;font-size:12px}}.card strong{{display:block;font-size:30px;color:#173a59;margin-top:8px}}
    .panel{{margin:18px 0}}.panel h2{{margin-top:0;font-size:18px}}table{{width:100%;border-collapse:collapse}}th,td{{text-align:left;padding:12px 9px;border-bottom:1px solid #e8edf1;font-size:13px}}
    th{{color:#77899b;text-transform:uppercase;font-size:10px;letter-spacing:.08em}}small{{display:block;color:#8796a5;margin-top:4px}}
    .pill{{background:#edf3f8;border-radius:20px;padding:5px 9px;font-size:11px}}.button{{display:inline-block;background:#2671a7;color:white;border:0;border-radius:7px;padding:10px 14px;text-decoration:none;cursor:pointer;font-weight:bold}}
    .secondary{{background:#eaf0f5;color:#38536b}}input,select,textarea{{width:100%;padding:10px;border:1px solid #d7e0e8;border-radius:7px;font:inherit;margin:5px 0 14px}}
    label{{font-size:12px;font-weight:bold;color:#536a7e}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px}}.wide{{grid-column:1/-1}}
    .msg{{padding:12px;background:#e3f5eb;color:#256b45;border-radius:8px;margin-bottom:14px}}.error{{background:#fff0ed;color:#a43d36}}
    footer{{text-align:center;color:#91a0ad;font-size:11px;padding:25px}}@media(max-width:700px){{.cards{{grid-template-columns:1fr 1fr}}.grid{{grid-template-columns:1fr}}.wide{{grid-column:auto}}header{{display:block}}header nav{{margin-top:10px}}}}
    </style></head><body><header><b>☀ SunTrack <small style="color:#b8d4e7">SERVICE DESK</small></b>
    <nav><a href="/">Overview</a><a href="/tickets">Tickets</a><a href="/new">＋ New ticket</a></nav></header>
    <main>{body}</main><footer>SunTrack Service Desk · Independent portfolio project · Sample data only</footer></body></html>"""

def dashboard():
    with connect() as db:
        total = db.execute("SELECT COUNT(*) FROM tickets").fetchone()[0]
        active = db.execute("SELECT COUNT(*) FROM tickets WHERE status!='Completed'").fetchone()[0]
        done = db.execute("SELECT COUNT(*) FROM tickets WHERE status='Completed'").fetchone()[0]
        billable = db.execute("SELECT COUNT(*) FROM tickets WHERE billable=1").fetchone()[0]
    rows = all_tickets()[:6]
    body = """<section class="hero"><h1>Keep every service call moving forward.</h1>
    <p>Manage customer issues, coordinate field work, and monitor service outcomes.</p>
    <a class="button" href="/new">＋ Create service ticket</a></section>"""
    body += '<section class="cards">'
    for label, value in [("Total tickets",total),("Active tickets",active),("Completed",done),("Billable flagged",billable)]:
        body += f'<div class="card"><span>{label}</span><strong>{value}</strong></div>'
    body += '</section><section class="panel"><h2>Recent service tickets</h2>'
    body += ticket_table(rows) if rows else '<p>No tickets yet. Create a sample ticket to explore the dashboard.</p>'
    body += '</section>'
    return layout("Overview", body)

def ticket_table(rows):
    if not rows: return "<p>No matching tickets.</p>"
    out = "<div style='overflow-x:auto'><table><tr><th>Customer</th><th>Service</th><th>Priority</th><th>Status</th><th>Billable</th><th>Action</th></tr>"
    for t in rows:
        out += (f"<tr><td><b>{escape(t['customer'])}</b><small>{escape(t['address'])}</small></td>"
                f"<td>{escape(t['service_type'])}</td><td><span class='pill'>{escape(t['priority'])}</span></td>"
                f"<td><span class='pill'>{escape(t['status'])}</span></td><td>{'Yes' if t['billable'] else 'No'}</td>"
                f"<td><a href='/complete/{t['id']}'>Complete</a></td></tr>")
    return out + "</table></div>"

def form_page(message=""):
    options = lambda values: "".join(f"<option>{escape(v)}</option>" for v in values)
    body = '<section class="panel"><h1>New service ticket</h1>'
    if message: body += f'<div class="msg error">{escape(message)}</div>'
    body += """<form method="post" action="/create"><div class="grid">
    <label>Customer name *<input name="customer" required></label>
    <label>Phone<input name="phone"></label>
    <label class="wide">Service address *<input name="address" required></label>
    <label>System size (kW)<input name="system_kw" type="number" min="0" step=".01"></label>
    <label>Service type<select name="service_type">""" + options(TYPES) + """</select></label>
    <label>Priority<select name="priority">""" + options(PRIORITIES) + """</select></label>
    <label>Status<select name="status">""" + options(STATUSES) + """</select></label>
    <label>Scheduled date<input name="scheduled_date" type="date"></label>
    <label class="wide">Issue description *<textarea name="description" rows="4" required></textarea></label>
    <label><input style="width:auto" type="checkbox" name="billable" value="1"> Flag for billable service review</label>
    </div><button class="button">Save ticket</button> <a class="button secondary" href="/tickets">Cancel</a></form></section>"""
    return layout("New ticket", body)

class Handler(BaseHTTPRequestHandler):
    def send_html(self, html, status=200):
        data = html.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/":
            return self.send_html(dashboard())
        if parsed.path == "/tickets":
            params = parse_qs(parsed.query)
            q = params.get("q", [""])[0]
            status = params.get("status", [""])[0]
            body = f"""<section class="panel"><h1>Service tickets</h1><form method="get">
            <input name="q" placeholder="Search customer, address, issue" value="{escape(q)}">
            <select name="status"><option value="">All statuses</option>"""
            for s in STATUSES:
                selected = " selected" if status == s else ""
                body += f'<option{selected}>{escape(s)}</option>'
            body += '</select><button class="button">Filter</button></form>'
            body += ticket_table(all_tickets(q,status)) + "</section>"
            return self.send_html(layout("Tickets",body))
        if parsed.path == "/new":
            return self.send_html(form_page())
        if parsed.path.startswith("/complete/"):
            try: ticket_id = int(parsed.path.rsplit("/",1)[1])
            except ValueError: return self.send_html(layout("Error","<h1>Invalid ticket ID</h1>"),400)
            update_status(ticket_id,"Completed")
            return self.redirect("/tickets")
        return self.send_html(layout("Not found","<h1>Page not found</h1>"),404)
    def do_POST(self):
        if urlparse(self.path).path != "/create":
            return self.send_html(layout("Not found","<h1>Page not found</h1>"),404)
        length = int(self.headers.get("Content-Length",0))
        data = {k:v[0] for k,v in parse_qs(self.rfile.read(length).decode(),keep_blank_values=True).items()}
        try:
            create_ticket(data)
        except ValueError as exc:
            return self.send_html(form_page(str(exc)),400)
        return self.redirect("/tickets")
    def redirect(self, path):
        self.send_response(303); self.send_header("Location",path); self.end_headers()
    def log_message(self, *_args): pass

def main():
    init_db()
    server = HTTPServer(("127.0.0.1", 8000), Handler)
    print("SunTrack running at http://127.0.0.1:8000")
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()

if __name__ == "__main__":
    main()
