# SunTrack Service Desk

A local solar service-management web application built with **Python's standard library** and **SQLite**. No third-party packages are required.

## Why I built it
I come from electrical and solar field operations. This project translates a familiar workflow—customer intake, troubleshooting, scheduling, priority, billable review, and closeout—into a small software product.

## Features
- Dashboard metrics: total, active, completed, and billable-flagged tickets
- Create customer service tickets with system size, service type, issue, priority, status, and scheduled date
- Search by customer, address, or issue description
- Filter by workflow status
- Mark tickets completed
- SQLite persistence and input validation
- Automated unit tests

## Stack
Python 3.10+ · `http.server` · `sqlite3` · HTML · CSS · `unittest`

## Run locally
```bash
python app.py
```
Open **http://127.0.0.1:8000**.

The database is created automatically as `solar_service.db` in the project folder.

## Run tests
```bash
python -m unittest discover -s tests -v
```

## Demo walkthrough
1. Open the dashboard.
2. Select **New ticket** and add a fictional inverter communication issue.
3. Return to Tickets and search by customer or issue.
4. Filter by status.
5. Mark the ticket complete and revisit the dashboard metrics.

Use fictional records only. Do not enter real customer personal information.

## Design decisions
- Used only Python's standard library to keep installation friction low.
- Used SQLite for durable local storage.
- Used parameterized SQL queries for search and inserts.
- Centralized ticket validation in `create_ticket`.
- Added automated tests for persistence, required fields, invalid categories, search, status updates, and billable flags.

## Limitations / next steps
This is a learning prototype, not a production-ready customer system. A production version should add authentication, CSRF protection, stronger input and output security, audit logs, pagination, configuration management, deployment hardening, and privacy review. Future enhancements could include technician assignment, inventory, CSV exports, a REST API, and billable rules based on PTO date.

## Portfolio disclosure
Independently built learning project demonstrating foundational Python, web request handling, database integration, validation, and automated testing. It is not represented as professional software engineering employment.
